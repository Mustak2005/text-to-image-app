# Text to Image App
A simple frontend for generating images from text.